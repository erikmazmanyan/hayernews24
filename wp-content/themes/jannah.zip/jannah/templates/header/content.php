<?php
/**
 * Header Content Area
 *
 * This template can be overridden by copying it to your-child-theme/templates/header/content.php.
 *
 * HOWEVER, on occasion TieLabs will need to update template files and you
 * will need to copy the new files to your child theme to maintain compatibility.
 *
 * @author 		TieLabs
 * @version   2.1.0
 */

defined( 'ABSPATH' ) || exit; // Exit if accessed directly

?>

<div class="container">
	<div class="tie-row logo-row">
<?php do_action( 'TieLabs/Logo/before_wrapper' ); ?>
<div class="logo-wrapper">
			<div class="tie-col-md-4 logo-container">
				<a href="https://exnews.live"><img src="https://exnews.live/wp-content/uploads/2021/10/96424162_1415273168673597_448204297176350720_n.jpg" width="400px" style="padding-top:40px; padding-bottom: 10px; float:left"></a>
		</div><!-- .tie-col /-->
		</div><!-- .logo-wrapper /-->

		<?php do_action( 'TieLabs/Logo/after_wrapper' ); ?>

	</div><!-- .tie-row /-->
</div><!-- .container /-->
